
  const loveIcon = document.getElementById('love-icon');
  const heartIcon = document.getElementById('heart');
  
  let isClicked = false;

  loveIcon.addEventListener('click', function() {
    if (isClicked) {
      heartIcon.classList.remove('clicked');
    } else {
      heartIcon.classList.add('clicked');
    }
    isClicked = !isClicked;
  });
