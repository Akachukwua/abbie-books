let hamMenuIcon = document.getElementById("ham-menu");
let navBar = document.getElementById("nav-bar");
let navLinks = navBar.querySelectorAll("li");

hamMenuIcon.addEventListener("click", () => {
  navBar.classList.toggle("active");
  hamMenuIcon.classList.toggle("fa-times");
});
navLinks.forEach((navLinks) => {
    navLinks.addEventListener("click", () => {
      
    // navBar.classList.remove("active");
    hamMenuIcon.classList.toggle("fa-times");
  });
});


// Get all the buttons that open the modal
const openModalButtons = document.querySelectorAll('.open-modal-button');
// Get all the buttons that close the modal
const closeModalButtons = document.querySelectorAll('.close-modal-button');
// Get all the modal elements
const modals = document.querySelectorAll('.modal');

// Function to open the modal
function openModal(modalId) {
  const modal = document.getElementById(modalId);
  modal.style.display = 'block';
}

// Function to close the modal
function closeModal() {
  modals.forEach((modal) => {
    modal.style.display = 'none';
  });
}

// Attach click event listeners to open modal buttons
openModalButtons.forEach((button) => {
  button.addEventListener('click', function() {
    const modalId = button.getAttribute('data-modal-target');
    openModal(modalId);
  });
});

// Attach click event listeners to close modal buttons
closeModalButtons.forEach((button) => {
  button.addEventListener('click', closeModal);
});

// Close the modal when the user clicks outside of it (optional)
window.addEventListener('click', function(event) {
  if (event.target.classList.contains('modal')) {
    closeModal();
  }
});



// Get all icons with the class "icon-toggle"
const icons = document.querySelectorAll(".icon-toggle");

// Add click event listener to each icon
icons.forEach(icon => {
    icon.addEventListener("click", function () {
        // Toggle the icon class between filled and outlined
        if (icon.classList.contains("far")) {
            icon.classList.remove("far");
            icon.classList.add("fas");
            icon.classList.remove("icon-active");
        } else {
            icon.classList.remove("fas");
            icon.classList.add("far");
            icon.classList.add("icon-active");
        }
    });
});

// const clickedElement = document.querySelectorAll('.clickable-element');
// clickedElement.forEach(element => {
//   element.addEventListener('click', function(e){
//     e.target.classList.toggle('active');
//   })
// });

const element2 = document.querySelector('#element2');
const element1 = document.querySelector('#element1');
const spanEl = document.querySelector('.active_span');

element2.addEventListener('click', function(){
  console.log('clicked');
  spanEl.classList.add('active');
})
element1.addEventListener('click', function(){
  console.log('1clicked');
  spanEl.classList.remove('active');
})


  let slideIndex = 0;
  showSlides();

  function showSlides() {
    const slides = document.querySelectorAll(".slide");
    for (let i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";  
    }
    slideIndex++;

    if (slideIndex > slides.length) {
      slideIndex = 1; // Restart the slideshow from the first slide
    }

    slides[slideIndex - 1].style.display = "block";  
    setTimeout(showSlides, 2000); // Change slides every 2 seconds (adjust as needed)
  }

